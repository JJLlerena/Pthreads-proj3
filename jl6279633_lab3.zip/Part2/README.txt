***** PTHREAD ASSIGNMENT PART 2 -Fibonacci Sequence- ***********


Running this pthread assignment is simple

using the provided Makefile use the "make" command from you terminal.
*this should compile the necessary executable file*
**command executed shown below from make**
"gcc -o multithread pthread2.c -lpthread"

Executing the file:
use the command "./Fibonacci [num]"

replace [num] with an integer to specify the number of values that will be implemented

this should result with the display of a fibonacci sequence with the number of values specified by command line input.

this will also display the sum of all the numbers in the sequence

****example***
./Fibonacci 10

0 1 1 2 3 5 8 13 21 34 55 89
sum = 232

***************
