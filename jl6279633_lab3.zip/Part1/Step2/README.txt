***** PTHREAD ASSIGNMENT PART 1 STEP 2 ***********


Running this pthread assignment is simple

using the provided Makefile use the "make" command from you terminal.
*this should compile the necessary executable file*
**command executed shown below from make**
"gcc -o multithread pthread1_2.c -lpthread"

Executing the file:
use the command "./multithread [num]"

replace [num] with an integer to specify the number of threads that will be used

this should result with an synchronized multithreaded print
